# PR #261 actual-main qualification

**Approved actual-main source delivery:** `d430ec5e0d7dcefc041df4ab5f80cb32382c5ac3`. All six candidate checks and all six fresh main push checks passed. No remaining finding.

Candidate: `bbcd446207aa1147bf924d8d397570dc987ac308`. Tree: `62b35e966af7aaf8ea0b85e1db465a182369c640`. Actual main has ordered parents `6a6a883f3ce1cd86a7405d2c53a1fb08cd1210c2` and `bbcd446207aa1147bf924d8d397570dc987ac308`. The candidate itself has parent `2206445c8498725f0f97098c83a4f21a7e0f69c9`. GitHub main and the merged PR agree on the actual merge commit.

## Fresh main gates

| Job | Result | Log qualification |
| --- | --- | --- |
| [CI / fast](https://github.com/MulattoTech/MTerm-CLI/actions/runs/43325124500/job/131555544335) | Passed | 1,543 tests: 1,531 passed, 12 expected skips |
| [ubuntu-24.04 / Node 24](https://github.com/MulattoTech/MTerm-CLI/actions/runs/43325124683/job/131555545412) | Passed | 1,543 tests: 1,531 passed, 12 expected skips |
| [macos-15-intel / Node 24](https://github.com/MulattoTech/MTerm-CLI/actions/runs/43325124683/job/131555545725) | Passed | 1,543 tests: 1,531 passed, 12 expected skips |
| [macos-15 / Node 24](https://github.com/MulattoTech/MTerm-CLI/actions/runs/43325124683/job/131555545818) | Passed | 1,543 tests: 1,531 passed, 12 expected skips |
| [Native Linux isolation / Node 24](https://github.com/MulattoTech/MTerm-CLI/actions/runs/43325124683/job/131555545879) | Passed | 12 real source plus 12 installed scenarios; all cleanup verified |
| [windows-2022 / Node 24](https://github.com/MulattoTech/MTerm-CLI/actions/runs/43325124683/job/131555546049) | Passed | 1,543 tests: 1,543 passed, 0 expected skips |

All five installed-package lanes passed 24 remote-profile tests and 81 endpoint tests from outside checkout. Compiled remote-module hashes match the reviewed build. Four pinned Codex registration lanes passed with zero model calls and no real-user configuration changes. The native live source and installed-package reports bind the actual main commit, with every scenario and cleanup check passing.

The exact source and criteria now have independent implementation, test and merge evidence. This review leaves ledger flags untouched; deployment and final acceptance remain unverified. The prior failed ordinary local check and its original lossless archive remain retained.

## Reusable evidence

`main-receipt.json` provides normalized candidate/main run and job identities, attempts, event types, head commits, workflow paths, statuses, URLs and log hashes. `api-identity.json` is self-contained in the existing delivery identity shape, including the connector-normalized PR, actual commit responses and parent lists, pinned workflow strings, individual run responses and complete job lists for both phases.

The original provider-returned JSON text is retained in `candidate-api-captures.json` and `main-api-captures.json`; `api-raw-manifest.json` supplies exact UTF-8 sizes and hashes. Original normalized PR and decoded workflow captures are retained separately. These are independently retrieved observations, not a GitHub signature.
