# PR #261 independent candidate qualification

**Approved for normal expected-head merge:** `bbcd446207aa1147bf924d8d397570dc987ac308`. No remaining finding.

Base `6a6a883f3ce1cd86a7405d2c53a1fb08cd1210c2`; tree `62b35e966af7aaf8ea0b85e1db465a182369c640`. GitHub synthetic merge `b7cf0257149fd3b4d47cbc8cf07186481a803742` has the same tree and ordered parents `[base, candidate]`.

All 1126 remote blobs and 54 directories match the prepared source. All 63 publication entries, all 19 retained validation artifacts, all 8 previously reviewed source hashes and all 43 input hashes verify. The two originally missing log artifacts are now present with unchanged producer bytes; the three-file corrective diff is documented.

## Six required candidate jobs

| Job | Result | Evidence |
| --- | --- | --- |
| CI / fast | Passed | [131545768313](https://github.com/MulattoTech/MTerm-CLI/actions/runs/43322257308/job/131545768313): 1543 tests, 1531 passed, 12 expected skips |
| macos-15 / Node 24 | Passed | [131545833257](https://github.com/MulattoTech/MTerm-CLI/actions/runs/43322257223/job/131545833257): 1543 tests, 1531 passed, 12 expected skips |
| windows-2022 / Node 24 | Passed | [131545833698](https://github.com/MulattoTech/MTerm-CLI/actions/runs/43322257223/job/131545833698): 1543 tests, 1543 passed, 0 expected skips |
| macos-15-intel / Node 24 | Passed | [131545833704](https://github.com/MulattoTech/MTerm-CLI/actions/runs/43322257223/job/131545833704): 1543 tests, 1531 passed, 12 expected skips |
| Native Linux isolation / Node 24 | Passed | [131545833845](https://github.com/MulattoTech/MTerm-CLI/actions/runs/43322257223/job/131545833845): 12 real source + 12 installed scenarios; all cleanup verified |
| ubuntu-24.04 / Node 24 | Passed | [131545834047](https://github.com/MulattoTech/MTerm-CLI/actions/runs/43322257223/job/131545834047): 1543 tests, 1531 passed, 12 expected skips |

Five package lanes passed 24 remote-profile and 81 endpoint tests outside checkout, with module hashes matching the reviewed build and zero model calls. All four pinned Codex registration lanes passed with correct platform/architecture, zero model calls and no real-user configuration changes. Native source and installed containment tests bind the tested synthetic merge.

The ordinary local full check remains recorded as failed: 1,543 tests, 1,504 pass, 27 unchanged isolation `listen EPERM` failures and 12 existing Windows-only skips. Its complete lossless archive and original hashes remain retained. The hosted successes do not rewrite that local result.

Implementation/test source qualification is now backed by the exact candidate gates and prior four-criterion review. Merge credit still requires normal merge and actual-main qualification. No deployment or final acceptance is granted.

The JSON receipt includes normalized run/job identities, exact source/input hashes, all log hashes, resolved publication finding, and explicit limits. No source, GitHub or production mutation was performed by the reviewer.
